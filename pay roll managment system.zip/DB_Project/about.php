<?php
include "./empnav.php";
?>

<div class=" pay">
    <h1 ><u>ABOUT US</u></h1>
 </div>    <!--pay -->


<div class="maincontainer">
<div class="about">
<div class="img">
    <img src="https://img.freepik.com/premium-photo/group-people-sitting-around-table-meeting-room_899894-5270.jpg" alt="">
</div>                   <!--  // img -->
<div class="aboutcontent">
<h2>Who we Are?</h2>
<p>Welcome to our Payroll Management System! We are a leading software company dedicated 
        to providing comprehensive and efficient payroll solutions for businesses of all sizes. 
         Our platform is designed to simplify and streamline the complex process of managing payroll,
          allowing businesses to focus on their core operations while ensuring accurate and timely 
           payroll processing for employees.</p>
<a href="" class="read-more">Read More!</a>
</div>                      <!---//aboutcontent-->                
 </div>                    <!--  about -->
     </div>                <!--   //maincontainer -->

<!------------------------------------------------------------------------------------------------------------------>
<div class="maincontainer">
<div class="about">
<div class="aboutcontent">
<h2>Our Mission</h2>
<p>Welcome to our Payroll Management System! We are a leading software company dedicated 
        to providing comprehensive and efficient payroll solutions for businesses of all sizes. 
         Our platform is designed to simplify and streamline the complex process of managing payroll,
          allowing businesses to focus on their core operations while ensuring accurate and timely 
           payroll processing for employees.</p>
<a href="" class="read-more">Read More!</a>

</div>                      <!---//aboutcontent--> 
<div class="img">
    <img src="https://img.freepik.com/premium-photo/group-people-sitting-around-table-meeting-room_899894-5270.jpg" alt="">
</div>                   <!--  // img -->              
 </div>                    <!--  about -->
     </div>                <!--   //maincontainer -->

<div class="members">  
    <h2>Our Team</h2>
    <div class="row2">
        <div class="fox">
            <img src="p1.jpg" alt="Manager">
            <h3>Manager</h3>   
        </div>
        <div class="fox">
            <img src="p2.jpg" alt="Employee 1">
            <h3>Employee 1</h3>
        </div>
        <div class="fox">
            <img src="p3.jpg" alt="Employee 2">
            <h3>Employee 2</h3>
        </div>
        <div class="fox">
          <img src="p4.jpg" alt="Employee 3">
          <h3>Employee 3</h3>
      </div>
    </div>
  </div> 

  <footer class="contact">
    <br>
    <h2>CONTACT US</h2>
    <p>Have questions? Want to learn more about how our Payroll Management System can benefit <br>
         your business? We'd love to hear from you! Get in touch with our friendly team at </p> <br>
         <div class="social-img">
            <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
            <a href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com/"><i class="fab fa-instagram"></i></a>
        </div> <p id="p2">or use the contact form on our website.</p> <a href="contactus.html" style="color: rgb(77, 77, 126);"><b>Contact Form!</b></a>
            <br>
      <p id="p3">  Join thousands of businesses already experiencing the benefits of our Payroll Management System. <br>
         Let's streamline your payroll process together!
        
        </p>
        <br>
</footer>
