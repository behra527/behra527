<?php
include "./navbr.php";
include "./connection.php";
$i = 1;
$sql = "SELECT * FROM loan AS l
        INNER JOIN employee AS e ON l.Employee_id = e.Employee_id  ";

$result = mysqli_query($conn, $sql);

if ($result) {
?>

<div class="cRank">
    <?php include "./sidelink.php"; ?>
    <div class="cRank2" style="margin-top:50px">
        <h1 id="head1"><b>Loan Application </b></h1>
        <hr>
        <table class="styled-table">
        <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Designation</th>
                    <th>Department</th>
                    <th>Amount Of Loan</th>
                    <th>Duration</th>
                    <th>Reason</th>
                    <th>Action</th>
                  </tr>
                </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                ?>
                    <tr>
                        <td><?php echo $row['Employee_id'] ?></td>
                        <td><?php echo $row['First_Name'] . " " . $row['Last_Name'] ?></td>
                        <td><?php echo $row['Designation'] ?></td>
                        <td><?php echo $row['Department'] ?></td>
                        <td><?php echo $row['amount'] ?></td>
                        <td><?php echo $row['duration'] ?></td>
                        <td><?php echo $row['reason'] ?></td>
                        <td><button id="approve" name="status" value="approve">Approve</button>
                        <button id="reject" name="status" value="reject">Reject</button></td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<?php
} else {
    echo "Error in SQL query: " . mysqli_error($conn);
}
?>
















