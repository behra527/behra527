<?php
include './connection.php';
include './navbr.php';

$searchErr = '';
$item_name = '';

if (isset($_GET['query'])) {
    $search = $_GET['query'];
    
    if (!empty($search)) {
        $search = mysqli_real_escape_string($conn, $search); 
        $query = "SELECT * FROM employee as e Inner Join phone_no as p ON e.Employee_id=p.Employee_id WHERE e.Designation LIKE '%$search%'";
        $result = mysqli_query($conn, $query);
        if ($result) {
            $item_name = mysqli_fetch_all($result, MYSQLI_ASSOC);
        } else {
            die("Error: " . mysqli_error($conn));
        }
    } else {
        $searchErr = "Please enter the information";
    }
}
?>
<div class="cRank">
<?php
include "./sidelink.php";
?>
<div class="cRank2">
        <form action="searchDG.php" method="get">
          <h1 id="head1"> <b> Search List </b>
            <div id="bar">
            <input  type="text" id="search" name="query" class="input" placeholder="Enter Emplyee Name" style="border-radius:5px">
            <button id="bRank">Search</button>
        </div>
        </h1>
        </form>
        <table class="styled-table">
        <thead>
            <tr>
            <th>Department</th>
                <th>Designation</th>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                
                <th>Contact</th>
            </tr>
        </thead>
        <?php
                 if(!$item_name)
                 {
                    echo '<tr>No Desgination Found</tr>';
                 }
                 else{
                    foreach($item_name as $key=>$row)
                    {
                        ?>

<tr>
<td><?php echo $row['Department'] ?></td>
    <td><?php echo $row['Designation'] ?></td>
    <td><?php echo $row['Employee_id'] ?></td>
    <td><?php echo $row['First_Name'] . " " . $row['Last_Name'] ?></td>
    <td><?php echo $row['Email'] ?></td>
    
    <td><?php echo $row['contact'] ?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
<?php
}
?>