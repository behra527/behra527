<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="contADMIN">
        <br>
        <h1 style="text-align: center; margin-top: 10px;">Welcome</h1>
    <img id="i1" height="100px" width="100px" src="img9.jpg">
    <h2>PAYROLL MANAGEMENT SYSTEM</h2>
    <button class="btn"><a href="admin.php">Login As Admin</a></button>
    <br>
    <br>
    <button class="btn"><a href="employee.php">Login As Employee</a></button>
</div>
</body>
</html>