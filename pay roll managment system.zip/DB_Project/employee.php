

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="contADMIN">
        <h1>Employee LOGIN</h1>
        <img id="i1" height="100px" width="100px" src="logo.jpg">
        <form method="POST" action="login.php">
            <label for="username">Email:</label>
            <br>
            <input type="text" name="email" id="aIN" class="input" placeholder="Enter your email " required>
            <br>
            <br>
            <label for="password">Password:</label>
            <br>
            <input type="password" name="epass" id="aIN" class="input" placeholder="********"  maxlength="8" required>
            <br>
            <br>
            <button type="submit" class="btn">Login</button>
        </form>
    </div>
</body>
</html>
