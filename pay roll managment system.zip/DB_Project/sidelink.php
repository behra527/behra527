<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
<body>
    

<div class="cRank1">
            <h4>
                <br>
                <a id="a1" href="eInfo.php">Employee Information</a><br><br>
                <hr>
                <br>
                <a id="a1" href="eSalary.php">Employee Salary</a><br><br>
                <hr>
                <br>
                <a id="a1" href="eAttendence.php">Employee Attendence</a><br><br>
                <hr>
                <br>
                <a id="a1" href="services.php">Services For Employee</a><br><br>
                <hr>
                <br>
                <a id="a1" href="eRank.php">Employee Desgination</a><br><br>
            </h4>
        </div>

        </body>