-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2023 at 07:00 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pay`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `Employee_Id` int(11) DEFAULT NULL,
  `District` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `Street_No` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`Employee_Id`, `District`, `City`, `Street_No`) VALUES
(233, 'GRW', 'GRW', 'Road'),
(NULL, NULL, NULL, NULL),
(NULL, NULL, NULL, NULL),
(231, 'GRW', 'GRW', 'Proop Gahara'),
(342, 'GRW', 'GRW', 'hsg');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_id` int(11) NOT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_id`, `UserName`, `Password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `adsalary`
--

CREATE TABLE `adsalary` (
  `Employee_Id` int(11) DEFAULT NULL,
  `monthSalary` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `per` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adsalary`
--

INSERT INTO `adsalary` (`Employee_Id`, `monthSalary`, `status`, `per`, `reason`) VALUES
(233, '2023-09-01', NULL, NULL, 'Due to reason'),
(233, '2023-09-01', NULL, 50, 'Due ');

-- --------------------------------------------------------

--
-- Table structure for table `allownces`
--

CREATE TABLE `allownces` (
  `Salary_id` int(11) DEFAULT NULL,
  `Allownce_id` int(11) NOT NULL,
  `Travel_Allownce` int(11) DEFAULT NULL,
  `Medical_Allownce` int(11) DEFAULT NULL,
  `Rental_Allownce` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `allownces`
--

INSERT INTO `allownces` (`Salary_id`, `Allownce_id`, `Travel_Allownce`, `Medical_Allownce`, `Rental_Allownce`) VALUES
(1, 1, 500, 500, 1000),
(1, 2, 300, 300, 300),
(1, 3, 300, 300, 300),
(1, 4, 300, 300, 300),
(2, 5, 200, 100, 300),
(2, 6, 2334, 324, 32);

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `Employee_id` int(11) DEFAULT NULL,
  `Attendence_id` int(11) NOT NULL,
  `Attendence_Date` date DEFAULT NULL,
  `Attendence_Status` varchar(255) DEFAULT NULL,
  `In_Time` time DEFAULT NULL,
  `Out_Time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`Employee_id`, `Attendence_id`, `Attendence_Date`, `Attendence_Status`, `In_Time`, `Out_Time`) VALUES
(233, 1, '2023-09-14', 'present', '13:05:00', '03:06:00'),
(233, 2, '2023-09-07', 'Present', '01:05:00', '05:03:00'),
(233, 3, '2023-09-07', 'Present', '13:06:00', '01:07:00'),
(233, 4, '2023-09-07', 'present', '03:19:00', '06:22:00'),
(231, 5, '2023-09-06', 'present', '05:49:00', '07:51:00'),
(231, 6, '2023-09-13', 'present', '12:53:00', '17:58:00');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_id` int(11) NOT NULL,
  `First_Name` varchar(255) DEFAULT NULL,
  `Last_Name` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `CNIC` varchar(255) DEFAULT NULL,
  `Designation` varchar(255) DEFAULT NULL,
  `Department` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_id`, `First_Name`, `Last_Name`, `Email`, `CNIC`, `Designation`, `Department`, `Password`) VALUES
(24, 'Ali', 'farooq', 'ali@gmail.com', '341019823465', 'Accountant', 'Hr', '123'),
(231, 'Shan', 'Ali', 'shan@gmail.com', '0059', 'SE', 'RE', 'shan123'),
(233, 'Waqar', 'Farooq', 'waqar@gmail.com', '2', 'RE', 'SE', 'waqar123'),
(342, 'Riyan', 'Bashir', 'riyan@gmai.com', '534', 'SE', 'RE', 'riyan123');

-- --------------------------------------------------------

--
-- Table structure for table `leaveapply`
--

CREATE TABLE `leaveapply` (
  `Employee_Id` int(11) DEFAULT NULL,
  `no_leave` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `apdate` date DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leaveapply`
--

INSERT INTO `leaveapply` (`Employee_Id`, `no_leave`, `status`, `apdate`, `reason`) VALUES
(233, 2001, NULL, '0000-00-00', 'Due To illness'),
(233, 2000, NULL, '0000-00-00', 'Due\r\n'),
(233, 10000, NULL, '0000-00-00', 'saa'),
(233, 4, NULL, '0000-00-00', 'Due to marriage');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `Employee_Id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`Employee_Id`, `amount`, `status`, `duration`, `reason`) VALUES
(233, 20000, NULL, 2, 'Due to Home'),
(231, 2147483647, NULL, 2300, 'meri merzi XD');

-- --------------------------------------------------------

--
-- Table structure for table `phone_no`
--

CREATE TABLE `phone_no` (
  `Employee_Id` int(11) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phone_no`
--

INSERT INTO `phone_no` (`Employee_Id`, `contact`) VALUES
(233, '32434'),
(NULL, NULL),
(NULL, NULL),
(231, '68121'),
(342, '44323');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `Employee_id` int(11) DEFAULT NULL,
  `Salary_id` int(11) NOT NULL,
  `Basic_Salary` int(11) DEFAULT NULL,
  `Bonus` int(11) DEFAULT NULL,
  `Salary_Issue_Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`Employee_id`, `Salary_id`, `Basic_Salary`, `Bonus`, `Salary_Issue_Date`) VALUES
(233, 1, 2000, 200, '2023-09-14'),
(231, 2, 3000, 300, '2023-09-14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD KEY `Employee_Id` (`Employee_Id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_id`);

--
-- Indexes for table `adsalary`
--
ALTER TABLE `adsalary`
  ADD KEY `Employee_Id` (`Employee_Id`);

--
-- Indexes for table `allownces`
--
ALTER TABLE `allownces`
  ADD PRIMARY KEY (`Allownce_id`),
  ADD KEY `Salary_id` (`Salary_id`);

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`Attendence_id`),
  ADD KEY `Employee_id` (`Employee_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_id`);

--
-- Indexes for table `leaveapply`
--
ALTER TABLE `leaveapply`
  ADD KEY `Employee_Id` (`Employee_Id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD KEY `Employee_Id` (`Employee_Id`);

--
-- Indexes for table `phone_no`
--
ALTER TABLE `phone_no`
  ADD KEY `Employee_Id` (`Employee_Id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`Salary_id`),
  ADD KEY `Employee_id` (`Employee_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allownces`
--
ALTER TABLE `allownces`
  MODIFY `Allownce_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `Attendence_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`Employee_Id`) REFERENCES `employee` (`Employee_id`);

--
-- Constraints for table `adsalary`
--
ALTER TABLE `adsalary`
  ADD CONSTRAINT `adsalary_ibfk_1` FOREIGN KEY (`Employee_Id`) REFERENCES `employee` (`Employee_id`);

--
-- Constraints for table `allownces`
--
ALTER TABLE `allownces`
  ADD CONSTRAINT `allownces_ibfk_1` FOREIGN KEY (`Salary_id`) REFERENCES `salary` (`Salary_id`);

--
-- Constraints for table `attendence`
--
ALTER TABLE `attendence`
  ADD CONSTRAINT `attendence_ibfk_1` FOREIGN KEY (`Employee_id`) REFERENCES `employee` (`Employee_id`);

--
-- Constraints for table `leaveapply`
--
ALTER TABLE `leaveapply`
  ADD CONSTRAINT `leaveapply_ibfk_1` FOREIGN KEY (`Employee_Id`) REFERENCES `employee` (`Employee_id`);

--
-- Constraints for table `loan`
--
ALTER TABLE `loan`
  ADD CONSTRAINT `loan_ibfk_1` FOREIGN KEY (`Employee_Id`) REFERENCES `employee` (`Employee_id`);

--
-- Constraints for table `phone_no`
--
ALTER TABLE `phone_no`
  ADD CONSTRAINT `phone_no_ibfk_1` FOREIGN KEY (`Employee_Id`) REFERENCES `employee` (`Employee_id`);

--
-- Constraints for table `salary`
--
ALTER TABLE `salary`
  ADD CONSTRAINT `salary_ibfk_1` FOREIGN KEY (`Employee_id`) REFERENCES `employee` (`Employee_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
