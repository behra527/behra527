<?php
include "./empnav.php";

?>

<div class="cRank" style="margin-top:50px">
<?php
include "./empSide.php";
?>
           <div class="cRank2">
           <h1 id="head1"> <b> Salary Detail </b></h1>
              <table class="styled-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Designation</th>
                    <th>Date of Salary</th>
                    <th>Basic Salary</th>
                    <th>Allowance</th>
                    <th>Tax</th>
                    <th>Leave Deduction</th>
                    <th>Total Salary</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td>Riyan Bashir</td>
                    <td>HR</td>
                    <td>1 July 2023</td>
                    <td>3000</td>
                    <td>200</td>
                    <td>100</td>
                    <td>0</td>
                    <td>3100</td>
           </div>
        </div>