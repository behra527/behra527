<?php
include "./navbr.php";
include "./connection.php";
$i = 1;

$sql = "SELECT e.Employee_id, e.First_Name, e.Last_Name, e.Department, e.Designation, COUNT(a.Employee_id) AS Total_Present
        FROM employee AS e
        INNER JOIN attendence AS a ON e.Employee_id = a.Employee_id
        GROUP BY e.Employee_id, e.First_Name, e.Last_Name, e.Department, e.Designation";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Error in SQL query: " . mysqli_error($conn));
}
?>

<div class="cRank">
    <?php include "./sidelink.php"; ?>

    <div class="cRank2" style="margin-top:50px">
        <h1 id="head1"> <b>Employee Attendance</b></h1>
        <hr>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>Attendance</th> <!-- Corrected column name here -->
                    <th>Leave</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                ?>
                        <tr>
                            <td><?php echo $row['Employee_id'] ?></td>
                            <td><?php echo $row['First_Name'] . " " . $row['Last_Name'] ?></td>
                            <td><?php echo $row['Department'] ?></td>
                            <td><?php echo $row['Designation'] ?></td>
                            <td><?php echo $row['Total_Present'] ?></td>
                        </tr>
                <?php
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
