<?php
include "./navbr.php";
include './connection.php';
$id = $fname = $lname = $str = $dr = $city = $email = $dob = $degn = $pass = $cnic = $phone = $dep = '';
if (isset($_GET['uid'])) {
    $id = $_GET['uid'];
    $sql = "SELECT * FROM employee as e
            INNER JOIN phone_no as p ON e.Employee_id = p.Employee_id
            INNER JOIN address as a ON e.Employee_id = a.Employee_id
            WHERE e.Employee_id=?";
    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        die('Error in preparing the SQL statement: ' . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, 'i', $id);

    if (!mysqli_stmt_execute($stmt)) {
        die('Error in executing the SQL statement: ' . mysqli_error($conn));
    }

    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $id = $row['Employee_id'];
        $fname = $row['First_Name'];
        $lname = $row['Last_Name'];
        $str = $row['Street_No'];
        $dr = $row['District'];
        $city = $row['City'];
        $email = $row['Email'];
    //    $dob = $row['DOB'];
        $degn = $row['Designation'];
        $pass = $row['Password'];
        $cnic = $row['CNIC'];
        $phone = $row['contact'];
        $dep = $row['Department'];
    }
}
if (isset($_POST['submit'])) {
    $new_id = $_POST['eid'];
    $new_fname = $_POST['name'];
    $new_lname = $_POST['lname'];
    $new_str = $_POST['str'];
    $new_dr = $_POST['dr'];
    $new_city = $_POST['city'];
    $new_email = $_POST['mail'];
    $new_dob = $_POST['dob'];
    $new_degn = $_POST['degn'];
    $new_pass = $_POST['pass'];
    $new_cnic = $_POST['cnic'];
    $new_phone = $_POST['phone'];
    $new_dep = $_POST['department'];
    $update_sql = "UPDATE `employee` SET `First_Name`=?, `Last_Name`=?, `Email`=?, `CNIC`=?, `Designation`=?, `Department`=?, `Password`=? WHERE Employee_id=?";
    $update_stmt = mysqli_prepare($conn, $update_sql);

    if (!$update_stmt) {
        die('Error in preparing the update SQL statement: ' . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($update_stmt, 'sssssssi', $new_fname, $new_lname, $new_email, $new_cnic, $new_degn, $new_dep, $new_pass, $new_id);
    if (mysqli_stmt_execute($update_stmt)) {
        $update_phone_sql = "UPDATE `phone_no` SET `contact`=? WHERE Employee_id=?";
        $update_phone_stmt = mysqli_prepare($conn, $update_phone_sql);

        if (!$update_phone_stmt) {
            die('Error in preparing the phone number update SQL statement: ' . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($update_phone_stmt, 'si', $new_phone, $new_id);
        $update_address_sql = "UPDATE `address` SET `District`=?, `City`=?, `Street_No`=? WHERE Employee_id=?";
        $update_address_stmt = mysqli_prepare($conn, $update_address_sql);

        if (!$update_address_stmt) {
            die('Error in preparing the address update SQL statement: ' . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($update_address_stmt, 'sssi', $new_dr, $new_city, $new_str, $new_id);
        mysqli_begin_transaction($conn);
        if (mysqli_stmt_execute($update_stmt) && mysqli_stmt_execute($update_phone_stmt) && mysqli_stmt_execute($update_address_stmt)) {
            mysqli_commit($conn);
            echo '<script>alert("Data Updated Successfully")</script>';
            header('location: eInfo.php');
            exit;
        } else {
            mysqli_rollback($conn);
            echo '<script>alert("Data Not Updated!")</script>';
        }
    } else {
        echo '<script>alert("Data Not Updated!")</script>';
    }
}
?>

<br><br>
<div class="container">
    <br>
    <h1>Update Employee Detail</h1>
    <form id="div1" method="POST" action="">
    <div id="dd">
          <label>Employee ID:</label>
          <input type="text" id="id" name="eid" class="input" value="<?php echo htmlspecialchars($id); ?>">
    <br>
    <label >Last Name</label>
          <input type="text" id="lname" name="lname" class="input" value="<?php echo htmlspecialchars($lname); ?>">
          <br>
          <label >District:</label><br>
          <input type="text" id="dr" name="dr" class="input" value="<?php echo htmlspecialchars($dr); ?>"><br>
          <label >City:</label><br>
          <input type="text" id="city" name="city" class="input" value="<?php echo htmlspecialchars($city); ?>"><br>
    <label >Email:</label><br>
          <input type="email" id="email" name="mail" class="input" value="<?php echo htmlspecialchars($email); ?>"><br>
          <label >Date of Birth:</label>
          <input type="date" id="dob" name="dob" class="input" value="<?php echo htmlspecialchars($dob); ?>"><br>
          <label >Department:</label>
          <input type="text" id="department" name="department" class="input" value="<?php echo htmlspecialchars($dep); ?>">
        </div>
        <div id="dd2">
        <label>First Name:</label>
          <input type="text" id="name" name="name" class="input" value="<?php echo htmlspecialchars($fname); ?>">
    <br>
          <label>CNIC No:</label>
          <input type="text" id="phone" name="cnic" class="input" value="<?php echo htmlspecialchars($cnic); ?>">
    <br>
    <label >Mobile No:</label>
    <input type="tel" id="phone" name="phone" class="input" value="<?php echo htmlspecialchars($phone); ?>"><br>
    <label >Street:</label><br>
          <input type="text" id="street" name="str" class="input" value="<?php echo htmlspecialchars($str); ?>"><br>
          <label >Assign Password:</label>
          <input type="text" id="pass" name="pass" class="input" value="<?php echo htmlspecialchars($pass); ?>"><br>
          
 <label >Desgination:</label>
          
        <input type="text" id="degn" name="degn" class="input" value="<?php echo htmlspecialchars($degn); ?>"><br>

          
        </div>
        <button type="submit" id="bADD" name="submit">Update Employee</button>
    </form>
<br>
</div>

