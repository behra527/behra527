<?php
include "./connection.php";
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["uname"];
    $password = $_POST["upassword"];
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);
    $query = "SELECT * FROM admin WHERE UserName = '$username' AND Password = '$password'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {
        $_SESSION["admin"] = true;
        header("Location: ahome.php");
        exit();
    } else {
        echo '<script>alert("Invalid credentials. Please enter right credentials")</script>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="contADMIN">
    <h1>ADMIN LOGIN</h1>
    <img id="i1" height="100px" width="100px" src="logo.jpg">
    <form method="POST">
        <label for="username" id="admin">Username:</label>
        <br>
        <input type="text" name="uname" class="input" id="aIN" placeholder="Enter your User-name" required>
        <br>
        <br>
        <label for="password" id="admin">Password:</label>
        <br>
        <input type="password" name="upassword" class="input" id="aIN" placeholder="********"  maxlength="8" required>
        <br>
        <br>
        <button class="btn">Login</button>
    </form>
</div>
</body>


</html>