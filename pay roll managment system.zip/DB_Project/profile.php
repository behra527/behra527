<?php
include "./empnav.php";
include "./login.php";
include "./connection.php";
$i = 1;
$email = mysqli_real_escape_string($conn, $_SESSION['emal']);
$sql = "SELECT * FROM employee as e Inner Join phone_no as p ON e.Employee_id=p.Employee_id Inner Join address as a ON e.Employee_id=a.Employee_id Where Email='$email'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
?>

<div class="cRank">
    <?php
    include "./empSide.php";
    ?>
    <h1 id="head2" Style="text-align: center; margin-top:50px"> <b> Personal Information </b></h1>
    <div class="cRank3" style="margin-right:23%">
        <br>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
        ?>
            <h3 id="head3">ID: <?php echo $row['Employee_id'] ?></h3>
            <h3 id="head3">Name: <?php echo $row['First_Name'] . " " . $row['Last_Name'] ?></h3>
            <h3 id="head3">Address:<?php echo $row['Street_No'] . " " . $row['City'] . " " . $row['District'] ?></h3>
            <h3 id="head3">Email:<?php echo $row['Email'] ?></h3>
            <h3 id="head3">CNIC:<?php echo $row['CNIC'] ?></h3>
            <h3 id="head3">Department:<?php echo $row['Department'] ?></h3>
            <h3 id="head3">Designation:<?php echo $row['Designation'] ?></h3>
            <h3 id="head3">Contact:<?php echo $row['contact'] ?></h3>
            <h3 id="head3">Password:<?php echo $row['Password'] ?></h3>
        <?php
        }
        ?>
        <br>
    </div>
</div>
<?php
} // Close the if statement
?>
