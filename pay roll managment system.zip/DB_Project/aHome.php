<?php
include "./navbr.php";
?>
<h1 id="head2"><b>Welcome Admin!</b></h1>
<div class="row">
    <div class="box">
        <img src="pro2.avif" alt="">
        <button class="btn1"><a href="eInfo.php">Employees Information</a></button>
    </div>
    <div class="box">
        <img src="attendance.jpg" alt="">
        <button class="btn2"><a href="eAttendence.php">Employees Attendance</a></button>
    </div>
    <div class="box">
        <img src="details2.jpg" alt="">
        <button class="btn3" ><a href="eSalary.php">Employees Salary Details</a></button>
    </div>
</div>
<div class="row2">
    <div class="box">
        <img src="aaa.jpg" alt="">
        <button class="btn4"><a href="services.php">Services For Employee</a></button>
    </div>
    <div class="box">
        <img src="salary img.jpg" alt="">
        <button class="btn4"><a href="eRank.php">Employees Designation</a></button>
        </div>
    </div>
</div>