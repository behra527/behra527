<?php
include "./empnav.php";
include "./connection.php";
include "./login.php";
$i = 1;
$email = mysqli_real_escape_string($conn, $_SESSION['emal']);

$sql = "SELECT * FROM employee WHERE Email='$email'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    if ($row = mysqli_fetch_assoc($result)) {
        $empID = $row['Employee_id'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $id = $empID;
    $mnth = $_POST['join'];
    $amount = $_POST['amt'];
    $reason = $_POST['reason'];
    $status = $_POST[''];
    $sql = "INSERT INTO `adsalary`(`Employee_Id`, `monthSalary`, `per`, `reason`) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $id, $mnth, $amount, $reason);
        $result = mysqli_stmt_execute($stmt);
        
        if ($result) {
            echo '<script>alert("Appllied Successfully")</script>';
            header("location: empSerives.php");
        } else {
            echo '<script>alert("Data Not Inserted")</script>';
        }
    } else {
        echo '<script>alert("Error in preparing the statement")</script>';
    }
}
?>

<div class="cRank">
<?php
include "./empSide.php";
?> <h1 id="head2"Style="text-align: center;  margin-top:50px"> <b> Apply For Advance Salary </b></h1>
           <div class="cRank3" style="margin-left:39%">
          
                <form method="POST">
                  <br>
                  <label >Salary of Month</label><br>
                  <input type="date" id="join" name="join" required class="input"><br>
                  <label>Salary Amount:</label><br>
          <hr>
    <input type="radio"  name="amt" id="amount" value="50">
    <label>Half Salary</label>
    
    <input type="radio"  name="amt" id="amount" value="100">
    <label>Full Salary</label>

    <br>
    <hr>
                  <label >Reason:</label><br>
                  <textarea name="reason" id="reason" cols="30" rows="10" class="input" required></textarea><br><br>
                  <button type="submit" id="bADD" style="width:100px; margin-bottom:10px" >Apply</button>
                </form>
           </div>
        </div>