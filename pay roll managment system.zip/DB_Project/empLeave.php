<?php
include "./empnav.php";
include "./connection.php";
include "./login.php";
$i = 1;
$email = mysqli_real_escape_string($conn, $_SESSION['emal']);

$sql = "SELECT * FROM employee WHERE Email='$email'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    if ($row = mysqli_fetch_assoc($result)) {
        $empID = $row['Employee_id'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $id = $empID;
    $numb = $_POST['star'];
    $leave = $_POST['leave'];
    $reason = $_POST['reason'];
    $status = $_POST[''];
    $sql = "INSERT INTO `leaveapply`(`Employee_Id`, `no_leave`, `apdate`, `reason`) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $id, $leave, $numb, $reason);
        $result = mysqli_stmt_execute($stmt);
        
        if ($result) {
            echo '<script>alert("Attendance Added Successfully")</script>';
            header("location: empSerives.php");
        } else {
            echo '<script>alert("Data Not Inserted")</script>';
        }
    } else {
        echo '<script>alert("Error in preparing the statement")</script>';
    }
}
?>

<div class="cRank">
<?php
include "./empSide.php";
?> <h1 id="head2" Style="text-align: center;  margin-top:35px"> <b> Apply For Leave </b></h1>
           <div class="cRank3" style="margin-left:39%">
          
                <form method="POST">
                    <br>
                  <label >Date</label><br>
                  <input type="date" id="join" name="star" required class="input"><br>
                  <label >Number of Leaves </label><br>
                  <input type="number" id="join" name="leave" required class="input" placeholder="Number Of Leaves"><br>
                  <label >Reason:</label><br>
                  <textarea name="reason" id="reason" cols="30" rows="10" class="input" required></textarea><br>
                  <button type="submit" id="bADD" style="width:100px; margin-bottom:10px" >Apply</button>
                </form>
           </div>
        </div>