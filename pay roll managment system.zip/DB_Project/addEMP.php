<?php
include "./navbr.php";
?>
<br><br>
<div class="container">
  <br>
        <h1>Add New Employee</h1>
        <form id="div1" method="POST" action="addEmpForm.php">
          <div id="dd">
          <label>Employee ID:</label>
          <input type="text" id="id" name="eid" class="input" required placeholder="Employee Id">
    <br>
    <label >Last Name</label>
          <input type="text" id="lname" name="lname" class="input" required placeholder="Last Name">
          <br>
          <label >District:</label><br>
          <input type="text" id="dr" name="dr" class="input" required placeholder="Employee District"><br>
          <label >City:</label><br>
          <input type="text" id="city" name="city" class="input" required placeholder="Employee City"><br>
    <label >Email:</label><br>
          <input type="email" id="email" name="mail" class="input" required placeholder="Emplyee Email"><br>
          <label >Date of Birth:</label>
          <input type="date" id="dob" name="dob" class="input" required><br>
          <label >Desgination:</label>
          <input type="text" id="degn" name="degn" class="input" required placeholder="Emplyee Desgination"><br>
        </div>
        <div id="dd2">
        <label>First Name:</label>
          <input type="text" id="name" name="name" class="input" required placeholder="First Name">
    <br>
          <label>CNIC No:</label>
          <input type="text" id="phone" name="cnic" class="input" placeholder="xxxxx-xxxxxxx-x" required>
    <br>
    <label >Mobile No:</label>
    <input type="tel" id="phone" name="phone" class="input" required placeholder="Emplyee contact"><br>
    <label >Street:</label><br>
          <input type="text" id="street" name="str" class="input" required placeholder="Employee Street"><br>
          <label >Assign Password:</label>
          <input type="text" id="pass" name="pass" class="input" required placeholder="Assign Password"><br>
          <label >Department:</label>
          <input type="text" id="department" name="department" class="input" required placeholder="Emplyee Department"><br>


          
        </div>
        <button type="submit" id="bADD">Add Employee</button>
        <br>
        </form>
        <br>
      </div>