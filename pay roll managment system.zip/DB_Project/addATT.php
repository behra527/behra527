<?php
include "./empnav.php";
?>
<br><br>
<div class="container">
  <br>
        <h1>Add Your Attendance</h1>
        <form id="div1" method="POST" action="attForm.php">
          <div id="dd">
          <label>Date</label><br>
          <input type="date" id="date" name="dte" class="input" required>
    <br>
    <label >Out Time</label>
          <input type="time" id="out" name="out" class="input" >
          <br>
        </div>
        <div id="dd2">
        <label >In Time</label>
          <input type="time" id="in" name="in" class="input" >
          <br>
          <label>Satuts:</label><br>
          
    <input type="radio"  name="stus" id="status" value="present">
    <label>Present</label>
    
    <input type="radio"  name="stus" id="status" value="absent">
    <label>Absent</label>
    <br>

          
        </div>
        <button type="submit" id="bADD">Add Attendance</button>
        <br>
        </form>
        <br>
      </div>