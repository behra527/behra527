<?php
include "./connection.php";
include "./login.php";
$i = 1;
$email = mysqli_real_escape_string($conn, $_SESSION['emal']);

$sql = "SELECT * FROM employee WHERE Email='$email'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    if ($row = mysqli_fetch_assoc($result)) {
        $empID = $row['Employee_id'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $id = $empID;
    $date = $_POST['dte'];
    $itime = $_POST['in'];
    $otime = $_POST['out'];
    $status = $_POST['stus'];
    $sql = "INSERT INTO `attendence`(`Employee_id`, `Attendence_Date`, `In_Time`, `Out_Time`, `Attendence_Status`) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "sssss", $id, $date, $itime, $otime, $status);
        $result = mysqli_stmt_execute($stmt);
        
        if ($result) {
            echo '<script>alert("Attendance Added Successfully")</script>';
            header("location: attendence.php");
        } else {
            echo '<script>alert("Data Not Inserted")</script>';
        }
    } else {
        echo '<script>alert("Error in preparing the statement")</script>';
    }
}
?>
