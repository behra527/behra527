<?php
include "./empnav.php";
include "./connection.php";
include "./login.php";
$i = 1;
$email = mysqli_real_escape_string($conn, $_SESSION['emal']);

$sql = "SELECT a.Attendence_id, e.First_Name, e.Last_Name, a.Attendence_Date, a.In_Time, a.Out_Time, a.Attendence_Status
        FROM employee AS e
        INNER JOIN attendence AS a ON e.Employee_id = a.Employee_id
        WHERE e.Email='$email'";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Error in SQL query: " . mysqli_error($conn));
}


?>

<div class="cRank">
    <?php
    include "./empSide.php";
    ?>
    <div class="cRank2" style="margin-top:50px">
        <h1 id="head1"> <b>Employee Attendance </b>
            <div id="bar">
                <button id="bRank"><a href="addATT.php">Add new Attendance</a></button>
            </div>
        </h1>
        <hr>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Attendance ID</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>In-Time</th>
                    <th>Out-Time</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                ?>
                    <tr>
                        <td><?php echo $row['Attendence_id'] ?></td>
                        <td><?php echo $row['First_Name'] . " " . $row['Last_Name'] ?></td>
                        <td><?php echo $row['Attendence_Date'] ?></td>
                        <td><?php echo $row['In_Time'] ?></td>
                        <td><?php echo $row['Out_Time'] ?></td>
                        <td><?php echo $row['Attendence_Status'] ?></td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<?php
}
?>
