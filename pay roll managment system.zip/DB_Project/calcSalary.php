<?php
include "./connection.php";
$i = 1;

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $id = $_POST['id'];
    $sid = $_POST['sid'];
    $pay = $_POST['bpay'];
    $medical = $_POST['medical'];
    $bonus = $_POST['bonus'];
    $home = $_POST['home'];
    $travel = $_POST['travel'];
    $date = $_POST['isDate'];
    $sql = "INSERT INTO `salary`(`Employee_id`, `Salary_id`, `Basic_Salary`, `Bonus`, `Salary_Issue_Date`) VALUES (?, ?, ?, ?, ?)";
    $sql1 = "INSERT INTO `allownces`(`Salary_id`, `Travel_Allownce`, `Medical_Allownce`, `Rental_Allownce`) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    $stmt1 = mysqli_prepare($conn, $sql1);
    
    if ($stmt && $stmt1) {
        mysqli_stmt_bind_param($stmt, "sssss", $id, $sid, $pay, $bonus, $date);
        mysqli_stmt_bind_param($stmt1, "ssss", $sid, $travel, $medical, $home);
      
        $result = mysqli_stmt_execute($stmt);
        $result1 = mysqli_stmt_execute($stmt1);
        
        if ($result) {
            echo '<script>alert("Salary and allowances added successfully")</script>';
            header("location: eSalary.php");
        } 
    } else {
        echo '<script>alert("Error in preparing the statement")</script>';
    }
}
?>


<div class="cRank">
    <?php include "./sidelink.php"; ?>
<div class="container" style="margin-top:50px">
    <br>
        <h1>Employee Salary Calculation</h1>
        <form method="POST">
          <div id="dd">
          <label >Employee ID:</label><br>
          <input type="text" id="id" name="id" class="input" required placeholder="Enter Employee ID">
    <br>
          <label >Basic Salary:</label><br>
          <input type="number" id="text" name="bpay" class="input" required placeholder="Enter Basic Pay">
    <br>
    <label >Medical Allowance:</label>
    <input type="number" id="mall" name="medical" class="input" placeholder="Enter Medical Allowance"><br>
    <label >Salary Issue Date:</label>
    <input type="date" id="mall" name="isDate" class="input" placeholder="Enter Medical Allowance"><br>
          <br>
    </div>
        <div id="dd2">
        <label >Salary ID:</label><br>
          <input type="text" id="id" name="sid" class="input" required placeholder="Enter Salary ID">
    <br>
        <label >Bonus</label><br>
          <input type="number" id="department" name="bonus" class="input" placeholder="Enter Bonus"><br>
          <label>Travel Allowance:</label>
          <input type="number" id="travel" name="travel" class="input" placeholder="Enter Travel Allowance">
    <br>
   
    
          <label >Home Allowance</label>
          <input type="number" id="hall" name="home" class="input" placeholder="Enter Home Allowance"> 
            <br>
            
        </div>
          <button type="submit" id="bADD">Calculate</button><br>
        </form>
        <br>
    </div>
</div>