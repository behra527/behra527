<?php
include "./empnav.php";
?>
<h1 id="head2"><b>Welcome Employee!</b></h1>
<div class="row2">
    <div class="box">
        <img src="pro2.avif" alt="">
        <button class="btn1"><a href="profile.php">Profile Informations</a></button>
    </div>
    <div class="box">
        <img src="attendance.jpg" alt="">
        <button class="btn2"><a href="attendence.php">Attendance Details</a></button>
    </div>
    </div>
    <div class="row2">
    <div class="box">
        <img src="details2.jpg" alt="">
        <button class="btn3" ><a href="salary.php">Salary Details</a></button>
    </div>
    <div class="box">
        <img src="aaa.jpg" alt="">
        <button class="btn4"><a href="empSerives.php">Application Services</a></button>
    </div>
    </div>
</div>