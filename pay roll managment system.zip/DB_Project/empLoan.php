<?php
include "./empnav.php";
include "./connection.php";
include "./login.php";
$i = 1;
$email = mysqli_real_escape_string($conn, $_SESSION['emal']);

$sql = "SELECT * FROM employee WHERE Email='$email'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    if ($row = mysqli_fetch_assoc($result)) {
        $empID = $row['Employee_id'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $id = $empID;
    $amount = $_POST['smt'];
    $duration = $_POST['join'];
    $reason = $_POST['reason'];
    $status = $_POST[''];
    $sql = "INSERT INTO `loan`(`Employee_Id`, `amount`, `duration`, `reason`) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $id, $amount, $duration, $reason);
        $result = mysqli_stmt_execute($stmt);
        
        if ($result) {
            echo '<script>alert("Appllied Successfully")</script>';
            header("location: empSerives.php");
        } else {
            echo '<script>alert("Data Not Inserted")</script>';
        }
    } else {
        echo '<script>alert("Error in preparing the statement")</script>';
    }
}
?>


<div class="cRank">
<?php
include "./empSide.php";
?> <h1 id="head2" Style="text-align: center;  margin-top:50px"> <b> Apply For Loan</b></h1>
           <div class="cRank3" style="margin-left:39%">
          
                <form method="POST">
                    <br>
                  <label >Loan Amount</label><br>
                  <input type="number" id="join" name="smt" required class="input" placeholder="Loan Amount"><br>
                  <label >Duration In Year </label><br>
                  <input type="number" id="join" name="join" required class="input" placeholder="Duration"><br>
                  <label >Reason:</label><br>
                  <textarea name="reason" id="reason" cols="30" rows="6" class="input" required></textarea><br><br>
                  <button type="submit" id="bADD" style="width:100px; margin-bottom:10px" >Apply</button>
                </form>
           </div>
        </div>