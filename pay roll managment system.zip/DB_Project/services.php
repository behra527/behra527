<?php
include "./navbr.php";
?>

<div class="cRank" style="margin-top:50px">
<?php
include "./sidelink.php";
?>
           <div class="cRank4">
<h1 id="head2"><b>Services</b></h1>
<div class="row2">
    <div class="box">
        <img src="loan.jpg" alt="">
        <button class="btn1"><a href="eLoan.php">Loan Application</a></button>
    </div>
    <div class="box">
        <img src="ss.jpg" alt="">
        <button class="btn2"><a href="eService.php">Advance Salary Application</a></button>
    </div>
    <div class="box">
        <img src="le.jpg" alt="">
        <button class="btn3" ><a href="eLeave.php">Leave Application</a></button>
    </div>
</div>

</div>