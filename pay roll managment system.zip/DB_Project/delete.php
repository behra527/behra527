<?php
include "./connection.php";
$cd = $_GET['id'];
$sql = "DELETE FROM employee where Employee_id = $cd";
$sql1 = "DELETE FROM phone_no where Employee_id = $cd";
$sql2 = "DELETE FROM address where Employee_id = $cd";
$result = mysqli_query($conn,$sql);
$result = mysqli_query($conn,$sql1);
$result = mysqli_query($conn,$sql2);
if($result)
{
    header("location: eInfo.php");
}

?>