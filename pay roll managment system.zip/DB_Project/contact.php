<?php
include "./empnav.php";
?>
<h2 style="text-align: center; color: rgb(114, 114, 195); font-size: 32px; "><b>Contact Us</b></h2>
              <div class="contained" >
                  <form action="">
                      <input type="text" placeholder="Name" class="input-field" required>
                      <br>
                      <input type="email" placeholder="Email" class="input-field" required>
                      <br>
                     
                      <input type="phone" placeholder="Phone no" class="input-field" required>
                      <br>
                      <br>
                      
                      <textarea name="Message"  placeholder="Write your message here"></textarea><br>
                      <button type="button" class="bt">Send Mesaage</button>
                      <p>The customer care representative is available from 09 am to 05 pm.
                        <br>  Contact: +92 311 1222681</p>
                  </form>
              </div>