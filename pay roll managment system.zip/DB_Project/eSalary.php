<?php
include "./navbr.php";
include "./connection.php";
$i = 1;

$sql = "SELECT * FROM salary AS s INNER JOIN allownces AS a ON s.Salary_id = a.Salary_id
        INNER JOIN employee AS e ON s.Employee_id = e.Employee_id
        Inner Join loan as l ON s.Employee_id=l.Employee_id
        Inner Join leaveapply as lp ON s.Employee_id=lp.Employee_id
        Inner Join adsalary as sa ON s.Employee_id=sa.Employee_id
        GROUP BY s.Employee_id";

$result = mysqli_query($conn, $sql);

if ($result) {
?>

<div class="cRank">
    <?php include "./sidelink.php"; ?>
    <div class="cRank2" style="margin-top:50px">
    <h1 id="head1"> <b> Salary Details </b>
           <div id="bar">
                <button id="bRank"><a href="calcSalary.php">Calculate Salary</a></button>

</div>
</h1>
        <hr>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Basic Pay</th>
                    <th>Bonus</th>
                    <th>Total Allowance</th>
                    
                    <th>Issue Date</th>
                    <th>Advance Salary Deduction</th>
                    <th>Leave Deduction</th>
                    <th>Loan Deduction</th> 
                    <th>Total Salary</th> 
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                  $Total=$row['Rental_Allownce']+$row['Medical_Allownce']+
                  $row['Travel_Allownce'];
                  $totalSalary=$row['Basic_Salary']+$row['Bonus']+$row['Rental_Allownce']+$row['Medical_Allownce']+
                  $row['Travel_Allownce']-(1.5*$row['Basic_Salary'])-($row['no_leave']*($row['Basic_Salary']/30))-($row['amount']/3)-($row['per']*$row['Basic_Salary']);
                ?>
                    <tr>
                        <td><?php echo $row['Employee_id'] ?></td>
                        <td><?php echo $row['First_Name'] . " " . $row['Last_Name'] ?></td>
                        <td><?php echo $row['Basic_Salary'] ?></td>
                        <td><?php echo $row['Bonus'] ?></td>
                        <td><?php echo $Total?></td>
        
                        <td><?php echo $row['Salary_Issue_Date'] ?></td>
                        <td><?php echo (1.5*$row['Basic_Salary']) ?></td>
                          <td><?php echo ($row['no_leave']*$row['Basic_Salary']) ?></td>
                    <td><?php echo ($row['amount']/3) ?></td> 
                    <td><?php echo $totalSalary ?></td> 
                  
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<?php
} else {
    echo "Error in SQL query: " . mysqli_error($conn);
}
?>
