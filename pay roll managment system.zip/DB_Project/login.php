<?php
include "./connection.php";
session_start();
$empID = ""; // Initialize $empID

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["email"]) && isset($_POST["epass"])) {
        $username = $_POST["email"];
        $password = $_POST["epass"];
        $username = mysqli_real_escape_string($conn, $username);
        $password = mysqli_real_escape_string($conn, $password);
        $query = "SELECT * FROM employee WHERE Email = '$username' AND Password = '$password'";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) == 1) {
            $_SESSION["employee"] = true;
            $_SESSION["emal"]=$username;
            header("Location: ehome.php");
            exit();
        } else {
            echo '<script>alert("Invalid credentials. Please enter the correct credentials")</script>';
        }
    }
}
?>
