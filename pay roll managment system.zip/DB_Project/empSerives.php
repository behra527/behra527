<?php
include "./navbr.php";
?>

<div class="cRank" style="margin-top:50px">
<?php
include "./empSide.php";
?>
           <div class="cRank4">
<h1 id="head2"><b>Services</b></h1>
<div class="row2">
    <div class="box">
        <img src="loan.jpg" alt="">
        <button class="btn1"><a href="empLoan.php">Apply For Loan</a></button>
    </div>
    <div class="box">
        <img src="ss.jpg" alt="">
        <button class="btn2"><a href="advance.php">Apply For Advance Salary</a></button>
    </div>
    <div class="box">
        <img src="le.jpg" alt="">
        <button class="btn3" ><a href="empLeave.php">Apply For Leave</a></button>
    </div>
</div>

</div>