<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<div class="cont">
        <img id="i1" height="70px" width="100px" src="logo.jpg">
        <li class="logbtn" id="navli"><a href="admin.php">Logout</a></li>
        <li class="nav" id="navli"><a href="addEMP.php">Add Employee</a></li>
        <li class="nav" id="navli"><a href="aHome.php">Home</a></li>
    </div>