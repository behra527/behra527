<?php
include "./connection.php";
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $id = $_POST['eid'];
    $fname = $_POST['name'];
    $lname = $_POST['lname'];
    $str = $_POST['str'];
    $dr = $_POST['dr'];
    $city = $_POST['city'];
    $email = $_POST['mail'];
    $dob = $_POST['dob'];
    $degn = $_POST['degn'];
    $pass = $_POST['pass'];
    $cnic = $_POST['cnic'];
    $phone = $_POST['phone'];
    $dep = $_POST['department'];
    $sql = "INSERT INTO `employee` (`Employee_id`, `First_Name`, `Last_Name`, `Email`, `CNIC`, `Designation`, `Department`, `Password`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $sql1 = "INSERT INTO `address`(`Employee_Id`, `District`, `City`, `Street_No`) VALUES (?, ?, ?, ?)";
    $sql2 = "INSERT INTO `phone_no`(`Employee_Id`, `contact`) VALUES (?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    $stmt1 = mysqli_prepare($conn, $sql1);
    $stmt2 = mysqli_prepare($conn, $sql2);
    if ($stmt && $stmt1 && $stmt2) {
        mysqli_stmt_bind_param($stmt, "ssssssss", $id, $fname, $lname, $email, $cnic, $degn, $dep, $pass);
        mysqli_stmt_bind_param($stmt1, "ssss", $id, $dr, $city, $str); // Fix missing parameter
        mysqli_stmt_bind_param($stmt2, "ss", $id, $phone); // Fix missing parameter
        $result = mysqli_stmt_execute($stmt);
        $result1 = mysqli_stmt_execute($stmt1);
        $result2 = mysqli_stmt_execute($stmt2);
        if ($result && $result1 && $result2) {
            echo '<script>alert("New Employee Added Successfully")</script>';
            header("location: ahome.php");
        } else {
            echo '<script>alert("Data Not Inserted")</script>';
        }
    } else {
        echo '<script>alert("Error in preparing the statement")</script>';
    }
}
?>
