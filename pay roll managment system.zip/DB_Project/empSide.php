        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
<body>
    

<div class="cRank1">
            <h4>
                <br>
                <a id="a1" href="profile.php">Profile Information</a><br><br>
                <hr>
                <br>
                <a id="a1" href="salary.php">Salary Detail</a><br><br>
                <hr>
                <br>
                <a id="a1" href="attendence.php">Attendence Detail</a><br><br>
                <hr>
                <br>
                <a id="a1" href="empSerives.php">Application Services</a>

            </h4>
        </div>

        </body>