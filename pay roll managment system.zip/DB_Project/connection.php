<?php

$servername = "localhost";
$username="root";
$password="";
$dbname="pay";

$conn =  mysqli_connect($servername,$username,$password,$dbname);
 

?>