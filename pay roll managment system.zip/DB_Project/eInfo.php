<?php
include "./navbr.php";
include "./connection.php";
$i = 1;

$sql = "SELECT * FROM employee as e Inner Join phone_no as p ON e.Employee_id=p.Employee_id Inner Join address as a ON e.Employee_id=a.Employee_id";
$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
?>

<div class="cRank">
<?php
include "./sidelink.php";
?>
<div class="cRank2" style="margin-top:50px">
    <form action="search.php" method="get">
        <!-- Your form content goes here -->
    
    <h1 id="head1"><b> Employee Information </b>
        <div id="bar">
            <input type="text" id="search" name="query" class="input" placeholder="Enter Employee Name" style="border-radius:5px">
            <button id="bRank">Search</button>
        </div>
    </h1>
    </form>
    <hr>
    <table class="styled-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Address</th>
                <th>Email</th>
                <td>CNIC</td>
                <th>Contact</th>
                <th>Password</th>
                <th>Action</th>
            </tr>
        </thead>
        <?php
        while($row = mysqli_fetch_assoc($result))
        {
        ?>

        <tr>
            <td><?php echo $row['Employee_id'] ?></td>
            <td><?php echo $row['First_Name'] . " " . $row['Last_Name'] ?></td>
            <td><?php echo $row['Street_No'] . " " . $row['City'] . " " . $row['District'] ?></td>
            <td><?php echo $row['Email'] ?></td>
            <td><?php echo $row['CNIC'] ?></td>
            <td><?php echo $row['contact'] ?></td>
            <td><?php echo $row['Password'] ?></td>
            <td>
                <button id="edit"><a href="edit.php?uid=<?php echo $row['Employee_id']; ?>" style="text-decoration: none;color: white">Edit</a></button>
                <button id="delete"><a href="delete.php?id=<?php echo $row['Employee_id']; ?>" style="text-decoration: none;color: white">Delete</a></button>
            </td>
        </tr>
        <?php
        }
        ?>
        </tbody>
    </table>
</div>
</div>
<?php
}
?>
