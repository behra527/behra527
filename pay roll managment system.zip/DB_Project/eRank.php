<?php
include "./navbr.php";
include "./connection.php";
$i = 1;

$sql = "SELECT * FROM employee as e Inner Join phone_no as p ON e.Employee_id=p.Employee_id ";
$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
?>

<div class="cRank">
<?php
include "./sidelink.php";
?>
<div class="cRank2" style="margin-top:50px">
    <form action="search.php" method="get">    
    <h1 id="head1"><b> Employees </b>
        <div id="bar">
            <input type="text" id="search" name="query" class="input" placeholder="Enter Employee Name" style="border-radius:5px">
            <button id="bRank">Search</button>
        </div>
    </h1>
    </form>
    <hr>
    <table class="styled-table">
        <thead>
            <tr>
            <th>Department</th>
                <th>Designation</th>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
            </tr>
        </thead>
        <?php
        while($row = mysqli_fetch_assoc($result))
        {
        ?>

        <tr>
            <td><?php echo $row['Department'] ?></td>
            <td><?php echo $row['Designation'] ?></td>
            <td><?php echo $row['Employee_id'] ?></td>
            <td><?php echo $row['First_Name'] . " " . $row['Last_Name'] ?></td>
            <td><?php echo $row['Email'] ?></td>
            <td><?php echo $row['contact'] ?></td>

        </tr>
        <?php
        }
        ?>
        </tbody>
    </table>
</div>
</div>
<?php
}
?>
